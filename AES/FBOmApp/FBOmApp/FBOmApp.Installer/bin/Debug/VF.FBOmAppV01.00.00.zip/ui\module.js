﻿(function () {
    'use strict';
    angular.module('VF.FBOmApp', []);
})();
